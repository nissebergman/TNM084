Texture, normals and fake light.
Tesselation not visible.
